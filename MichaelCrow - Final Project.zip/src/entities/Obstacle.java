package entities;

import org.newdawn.slick.opengl.Texture;

public class Obstacle extends Entity {
	
	public Obstacle(Texture texture, int x, int y, int w, int h) {
		super(texture, x, y, w, h);
	}

}
