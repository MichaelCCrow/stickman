package entities;

public class Ground extends Entity {
	
	public Ground(String texturePath, int x, int y, int w, int h) {
		super(texturePath, x, y, w, h);
	}

}
