//package entities;
//
//public class BackgroundFactory {
//	
//	public Background makeBackground(String backgroundType) {
//		
//		Background newBackground = null;
//		
//		if (backgroundType.equalsIgnoreCase("stoneFloor")) {
//			
//			return new GroundFloor();
//		}
//		
//		else return null;
//	}
//
//}
