package game;

public interface Player {
	
	public void update(float delta);

}
